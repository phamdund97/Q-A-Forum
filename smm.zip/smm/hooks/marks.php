<?php
	// For help on using hooks, please refer to https://bigprof.com/appgini/help/working-with-generated-web-database-application/hooks

	function marks_init(&$options, $memberInfo, &$args){

		return TRUE;
	}

	function marks_header($contentType, $memberInfo, &$args){
		$header='';

		switch($contentType){
			case 'tableview':
				$header='';
				break;

			case 'detailview':
				$header='';
				break;

			case 'tableview+detailview':
				$header='';
				break;

			case 'print-tableview':
				$header='';
				break;

			case 'print-detailview':
				$header='';
				break;

			case 'filters':
				$header='';
				break;
		}

		return $header;
	}

	function marks_footer($contentType, $memberInfo, &$args){
		$footer='';

		switch($contentType){
			case 'tableview':
				$footer='';
				break;

			case 'detailview':
				$footer='';
				break;

			case 'tableview+detailview':
				$footer='';
				break;

			case 'print-tableview':
				$footer='';
				break;

			case 'print-detailview':
				$footer='';
				break;

			case 'filters':
				$footer='';
				break;
		}

		return $footer;
	}

	function marks_before_insert(&$data, $memberInfo, &$args){
		$marks=$data['marks'];
		if ($marks>100) {
			# code...
			$_SESSION['custom_err_msg']="<b>Sorry You cannot enter marks greater than 100</b>";
			return FALSE;
		}
		if ($marks<=100) {
			# code...
			$grade="A";
		}
		if ($marks<=74) {
			# code...
			$grade="B";
		}
		if ($marks<=59) {
			# code...
			$grade="C";
		}
		if ($marks<=49) {
			# code...
			$grade="D";
		}
		if ($marks<40) {
			# code...
			$grade="E";
		}
		$data['grade']=$grade;
		return TRUE;
	}

	function marks_after_insert($data, $memberInfo, &$args){
		$studID=$data['reg_no'];
		$ayID=$data['academic_year'];
		$unitID=$data['unit'];
		$marks=$data['marks'];
		$grade=$data['grade'];
		$getRegno=sqlValue("SELECT reg_no FROM students WHERE id='$studID'");
		$getStudent=sqlValue("SELECT full_name FROM students WHERE id='$studID'");
		$getYos=sqlValue("SELECT year_of_study FROM students WHERE id='$studID'");
		$getUnit=sqlValue("SELECT name FROM units WHERE id='$unitID'");
		$getAcademicYear=sqlValue("SELECT name FROM academic_years WHERE id='$ayID'");
		$getSemester=sqlValue("SELECT semester FROM academic_years WHERE id='$ayID'");
		$fullAY=$getAcademicYear.'-'.$getSemester;
		sql("INSERT INTO transcripts (reg_no,student,yos,academic_year,unit,marks,grade) VALUES('$getRegno','$getStudent','$getYos','$fullAY','$getUnit','$marks','$grade')");

		return TRUE;
	}

	function marks_before_update(&$data, $memberInfo, &$args){
		$marks=$data['marks'];
		if ($marks>100) {
			# code...
			$_SESSION['custom_err_msg']="<b>Sorry You cannot enter marks greater than 100</b>";
			return FALSE;
		}
		if ($marks<=100) {
			# code...
			$grade="A";
		}
		if ($marks<=74) {
			# code...
			$grade="B";
		}
		if ($marks<=59) {
			# code...
			$grade="C";
		}
		if ($marks<=49) {
			# code...
			$grade="D";
		}
		if ($marks<40) {
			# code...
			$grade="E";
		}
		$data['grade']=$grade;
		return TRUE;
	}

	function marks_after_update($data, $memberInfo, &$args){
		$studID=$data['reg_no'];
		$ayID=$data['academic_year'];
		$unitID=$data['unit'];
		$marks=$data['marks'];
		$grade=$data['grade'];
		$getRegno=sqlValue("SELECT reg_no FROM students WHERE id='$studID'");
		$getStudent=sqlValue("SELECT full_name FROM students WHERE id='$studID'");
		$getYos=sqlValue("SELECT year_of_study FROM students WHERE id='$studID'");
		$getUnit=sqlValue("SELECT name FROM units WHERE id='$unitID'");
		$getAcademicYear=sqlValue("SELECT name FROM academic_years WHERE id='$ayID'");
		$getSemester=sqlValue("SELECT semester FROM academic_years WHERE id='$ayID'");
		$fullAY=$getAcademicYear.'-'.$getSemester;
		sql("INSERT INTO transcripts (reg_no,student,yos,academic_year,unit,marks,grade) VALUES('$getRegno','$getStudent','$getYos','$fullAY','$getUnit','$marks','$grade')");
		sql("UPDATE transcripts SET reg_no='$getRegno',student='$getStudent',yos='$getYos',academic_year='$fullAY',unit='$getUnit',marks='$marks',grade='$grade'");
		return TRUE;
	}

	function marks_before_delete($selectedID, &$skipChecks, $memberInfo, &$args){

		return TRUE;
	}

	function marks_after_delete($selectedID, $memberInfo, &$args){

	}

	function marks_dv($selectedID, $memberInfo, &$html, &$args){

	}

	function marks_csv($query, $memberInfo, &$args){

		return $query;
	}
	function marks_batch_actions(&$args){

		return array();
	}
