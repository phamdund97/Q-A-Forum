var FiltersEnabled = 0; // if your not going to use transitions or filters in any of the tips set this to 0
var spacer="&nbsp; &nbsp; &nbsp; ";

// email notifications to admin
notifyAdminNewMembers0Tip=["", spacer+"No email notifications to admin."];
notifyAdminNewMembers1Tip=["", spacer+"Notify admin only when a new member is waiting for approval."];
notifyAdminNewMembers2Tip=["", spacer+"Notify admin for all new sign-ups."];

// visitorSignup
visitorSignup0Tip=["", spacer+"If this option is selected, visitors will not be able to join this group unless the admin manually moves them to this group from the admin area."];
visitorSignup1Tip=["", spacer+"If this option is selected, visitors can join this group but will not be able to sign in unless the admin approves them from the admin area."];
visitorSignup2Tip=["", spacer+"If this option is selected, visitors can join this group and will be able to sign in instantly with no need for admin approval."];

// students table
students_addTip=["",spacer+"This option allows all members of the group to add records to the 'Students' table. A member who adds a record to the table becomes the 'owner' of that record."];

students_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Students' table."];
students_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Students' table."];
students_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Students' table."];
students_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Students' table."];

students_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Students' table."];
students_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Students' table."];
students_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Students' table."];
students_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Students' table, regardless of their owner."];

students_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Students' table."];
students_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Students' table."];
students_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Students' table."];
students_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Students' table."];

// units table
units_addTip=["",spacer+"This option allows all members of the group to add records to the 'Units' table. A member who adds a record to the table becomes the 'owner' of that record."];

units_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Units' table."];
units_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Units' table."];
units_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Units' table."];
units_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Units' table."];

units_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Units' table."];
units_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Units' table."];
units_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Units' table."];
units_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Units' table, regardless of their owner."];

units_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Units' table."];
units_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Units' table."];
units_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Units' table."];
units_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Units' table."];

// exams table
exams_addTip=["",spacer+"This option allows all members of the group to add records to the 'Exams' table. A member who adds a record to the table becomes the 'owner' of that record."];

exams_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Exams' table."];
exams_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Exams' table."];
exams_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Exams' table."];
exams_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Exams' table."];

exams_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Exams' table."];
exams_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Exams' table."];
exams_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Exams' table."];
exams_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Exams' table, regardless of their owner."];

exams_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Exams' table."];
exams_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Exams' table."];
exams_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Exams' table."];
exams_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Exams' table."];

// academic_years table
academic_years_addTip=["",spacer+"This option allows all members of the group to add records to the 'Academic years' table. A member who adds a record to the table becomes the 'owner' of that record."];

academic_years_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Academic years' table."];
academic_years_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Academic years' table."];
academic_years_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Academic years' table."];
academic_years_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Academic years' table."];

academic_years_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Academic years' table."];
academic_years_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Academic years' table."];
academic_years_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Academic years' table."];
academic_years_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Academic years' table, regardless of their owner."];

academic_years_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Academic years' table."];
academic_years_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Academic years' table."];
academic_years_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Academic years' table."];
academic_years_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Academic years' table."];

// marks table
marks_addTip=["",spacer+"This option allows all members of the group to add records to the 'Marks' table. A member who adds a record to the table becomes the 'owner' of that record."];

marks_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Marks' table."];
marks_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Marks' table."];
marks_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Marks' table."];
marks_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Marks' table."];

marks_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Marks' table."];
marks_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Marks' table."];
marks_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Marks' table."];
marks_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Marks' table, regardless of their owner."];

marks_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Marks' table."];
marks_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Marks' table."];
marks_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Marks' table."];
marks_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Marks' table."];

// transcripts table
transcripts_addTip=["",spacer+"This option allows all members of the group to add records to the 'Transcripts' table. A member who adds a record to the table becomes the 'owner' of that record."];

transcripts_view0Tip=["",spacer+"This option prohibits all members of the group from viewing any record in the 'Transcripts' table."];
transcripts_view1Tip=["",spacer+"This option allows each member of the group to view only his own records in the 'Transcripts' table."];
transcripts_view2Tip=["",spacer+"This option allows each member of the group to view any record owned by any member of the group in the 'Transcripts' table."];
transcripts_view3Tip=["",spacer+"This option allows each member of the group to view all records in the 'Transcripts' table."];

transcripts_edit0Tip=["",spacer+"This option prohibits all members of the group from modifying any record in the 'Transcripts' table."];
transcripts_edit1Tip=["",spacer+"This option allows each member of the group to edit only his own records in the 'Transcripts' table."];
transcripts_edit2Tip=["",spacer+"This option allows each member of the group to edit any record owned by any member of the group in the 'Transcripts' table."];
transcripts_edit3Tip=["",spacer+"This option allows each member of the group to edit any records in the 'Transcripts' table, regardless of their owner."];

transcripts_delete0Tip=["",spacer+"This option prohibits all members of the group from deleting any record in the 'Transcripts' table."];
transcripts_delete1Tip=["",spacer+"This option allows each member of the group to delete only his own records in the 'Transcripts' table."];
transcripts_delete2Tip=["",spacer+"This option allows each member of the group to delete any record owned by any member of the group in the 'Transcripts' table."];
transcripts_delete3Tip=["",spacer+"This option allows each member of the group to delete any records in the 'Transcripts' table."];

/*
	Style syntax:
	-------------
	[TitleColor,TextColor,TitleBgColor,TextBgColor,TitleBgImag,TextBgImag,TitleTextAlign,
	TextTextAlign,TitleFontFace,TextFontFace, TipPosition, StickyStyle, TitleFontSize,
	TextFontSize, Width, Height, BorderSize, PadTextArea, CoordinateX , CoordinateY,
	TransitionNumber, TransitionDuration, TransparencyLevel ,ShadowType, ShadowColor]

*/

toolTipStyle=["white","#00008B","#000099","#E6E6FA","","images/helpBg.gif","","","","\"Trebuchet MS\", sans-serif","","","","3",400,"",1,2,10,10,51,1,0,"",""];

applyCssFilter();
