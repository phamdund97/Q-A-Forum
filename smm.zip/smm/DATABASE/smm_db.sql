-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 03, 2018 at 05:26 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.0.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smm_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_years`
--

CREATE TABLE `academic_years` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(40) NOT NULL,
  `semester` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `academic_years`
--

INSERT INTO `academic_years` (`id`, `name`, `semester`) VALUES
(1, '2017/2018', '1');

-- --------------------------------------------------------

--
-- Table structure for table `exams`
--

CREATE TABLE `exams` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exams`
--

INSERT INTO `exams` (`id`, `name`) VALUES
(1, 'CAT 1'),
(2, 'CAT 2'),
(3, 'MAIN EXAM');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `id` int(10) UNSIGNED NOT NULL,
  `reg_no` int(10) UNSIGNED NOT NULL,
  `student` int(10) UNSIGNED DEFAULT NULL,
  `unit` int(10) UNSIGNED NOT NULL,
  `marks` int(11) NOT NULL,
  `grade` varchar(40) DEFAULT NULL,
  `academic_year` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`id`, `reg_no`, `student`, `unit`, `marks`, `grade`, `academic_year`) VALUES
(3, 1, 1, 5, 56, 'D', 1),
(4, 1, 1, 3, 25, 'E', 1),
(5, 1, 1, 2, 58, 'C', 1),
(6, 1, 1, 4, 88, 'A', 1),
(7, 2, 2, 5, 76, 'A', 1),
(8, 2, 2, 3, 45, 'D', 1),
(10, 2, 2, 1, 44, 'D', 1);

-- --------------------------------------------------------

--
-- Table structure for table `membership_grouppermissions`
--

CREATE TABLE `membership_grouppermissions` (
  `permissionID` int(10) UNSIGNED NOT NULL,
  `groupID` int(11) DEFAULT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT '0',
  `allowEdit` tinyint(4) NOT NULL DEFAULT '0',
  `allowDelete` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_grouppermissions`
--

INSERT INTO `membership_grouppermissions` (`permissionID`, `groupID`, `tableName`, `allowInsert`, `allowView`, `allowEdit`, `allowDelete`) VALUES
(1, 2, 'students', 1, 3, 3, 3),
(2, 2, 'units', 1, 3, 3, 3),
(3, 2, 'exams', 1, 3, 3, 3),
(4, 2, 'academic_years', 1, 3, 3, 3),
(5, 2, 'marks', 1, 3, 3, 3),
(6, 2, 'transcripts', 1, 3, 3, 3),
(7, 3, 'students', 0, 3, 0, 0),
(8, 3, 'units', 0, 3, 0, 0),
(9, 3, 'exams', 0, 3, 0, 0),
(10, 3, 'academic_years', 0, 3, 0, 0),
(11, 3, 'marks', 1, 1, 0, 0),
(12, 3, 'transcripts', 0, 0, 0, 0),
(13, 4, 'students', 0, 0, 0, 0),
(14, 4, 'units', 0, 0, 0, 0),
(15, 4, 'exams', 0, 0, 0, 0),
(16, 4, 'academic_years', 0, 0, 0, 0),
(17, 4, 'marks', 0, 0, 0, 0),
(18, 4, 'transcripts', 0, 3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `membership_groups`
--

CREATE TABLE `membership_groups` (
  `groupID` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `description` text,
  `allowSignup` tinyint(4) DEFAULT NULL,
  `needsApproval` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_groups`
--

INSERT INTO `membership_groups` (`groupID`, `name`, `description`, `allowSignup`, `needsApproval`) VALUES
(1, 'anonymous', 'Anonymous group created automatically on 2018-09-03', 0, 0),
(2, 'Admins', 'Admin group created automatically on 2018-09-03', 0, 1),
(3, 'lecturers', 'all lecturers', 0, 1),
(4, 'students', 'all students', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `membership_userpermissions`
--

CREATE TABLE `membership_userpermissions` (
  `permissionID` int(10) UNSIGNED NOT NULL,
  `memberID` varchar(20) NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `allowInsert` tinyint(4) DEFAULT NULL,
  `allowView` tinyint(4) NOT NULL DEFAULT '0',
  `allowEdit` tinyint(4) NOT NULL DEFAULT '0',
  `allowDelete` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `membership_userrecords`
--

CREATE TABLE `membership_userrecords` (
  `recID` bigint(20) UNSIGNED NOT NULL,
  `tableName` varchar(100) DEFAULT NULL,
  `pkValue` varchar(255) DEFAULT NULL,
  `memberID` varchar(20) DEFAULT NULL,
  `dateAdded` bigint(20) UNSIGNED DEFAULT NULL,
  `dateUpdated` bigint(20) UNSIGNED DEFAULT NULL,
  `groupID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_userrecords`
--

INSERT INTO `membership_userrecords` (`recID`, `tableName`, `pkValue`, `memberID`, `dateAdded`, `dateUpdated`, `groupID`) VALUES
(1, 'students', '1', 'admin', 1535983029, 1535983029, 2),
(2, 'units', '1', 'admin', 1535983055, 1535983055, 2),
(3, 'units', '2', 'admin', 1535983069, 1535983069, 2),
(4, 'units', '3', 'admin', 1535983081, 1535983081, 2),
(5, 'units', '4', 'admin', 1535983097, 1535983097, 2),
(6, 'units', '5', 'admin', 1535983112, 1535983112, 2),
(7, 'exams', '1', 'admin', 1535983149, 1535983149, 2),
(8, 'exams', '2', 'admin', 1535983160, 1535983160, 2),
(9, 'exams', '3', 'admin', 1535983173, 1535983173, 2),
(10, 'academic_years', '1', 'admin', 1535983196, 1535983196, 2),
(12, 'marks', '3', 'admin', 1535985205, 1535985205, 2),
(13, 'marks', '4', 'admin', 1535985544, 1535985544, 2),
(14, 'marks', '5', 'admin', 1535985658, 1535985658, 2),
(15, 'marks', '6', 'admin', 1535985722, 1535985722, 2),
(16, 'students', '2', 'admin', 1535985841, 1535985841, 2),
(17, 'marks', '7', 'admin', 1535985876, 1535985876, 2),
(18, 'marks', '8', 'admin', 1535985907, 1535985907, 2),
(20, 'marks', '10', 'admin', 1535986925, 1535986925, 2);

-- --------------------------------------------------------

--
-- Table structure for table `membership_users`
--

CREATE TABLE `membership_users` (
  `memberID` varchar(20) NOT NULL,
  `passMD5` varchar(40) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `signupDate` date DEFAULT NULL,
  `groupID` int(10) UNSIGNED DEFAULT NULL,
  `isBanned` tinyint(4) DEFAULT NULL,
  `isApproved` tinyint(4) DEFAULT NULL,
  `custom1` text,
  `custom2` text,
  `custom3` text,
  `custom4` text,
  `comments` text,
  `pass_reset_key` varchar(100) DEFAULT NULL,
  `pass_reset_expiry` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `membership_users`
--

INSERT INTO `membership_users` (`memberID`, `passMD5`, `email`, `signupDate`, `groupID`, `isBanned`, `isApproved`, `custom1`, `custom2`, `custom3`, `custom4`, `comments`, `pass_reset_key`, `pass_reset_expiry`) VALUES
('admin', '827ccb0eea8a706c4c34a16891f84e7b', 'ronniengoda@gmail.com', '2018-09-03', 2, 0, 1, NULL, NULL, NULL, NULL, 'Admin member created automatically on 2018-09-03\nRecord updated automatically on 2018-09-03\nRecord updated automatically on 2018-09-03', NULL, NULL),
('caleb', '827ccb0eea8a706c4c34a16891f84e7b', 'cusso@gmail.com', '2018-09-03', 4, 0, 1, 'caleb nyairo', '0708344101', '', '', 'member signed up through the registration form.', NULL, NULL),
('guest', NULL, NULL, '2018-09-03', 1, 0, 1, NULL, NULL, NULL, NULL, 'Anonymous member created automatically on 2018-09-03', NULL, NULL),
('wanami', '827ccb0eea8a706c4c34a16891f84e7b', 'wanami@gmail.com', '2018-09-03', 3, 0, 1, 'wanami wanami', '0712345678', '', '', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(10) UNSIGNED NOT NULL,
  `reg_no` varchar(40) NOT NULL,
  `full_name` varchar(40) NOT NULL,
  `course` varchar(40) NOT NULL,
  `year_of_study` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `reg_no`, `full_name`, `course`, `year_of_study`) VALUES
(1, 'TED/118/16', 'rontiago rotiago', 'Technology Education', '2nd'),
(2, 'TED/119/16', 'Caleb Nyairo', 'Technology Education', '2nd');

-- --------------------------------------------------------

--
-- Table structure for table `transcripts`
--

CREATE TABLE `transcripts` (
  `id` int(10) UNSIGNED NOT NULL,
  `reg_no` varchar(40) DEFAULT NULL,
  `student` varchar(40) DEFAULT NULL,
  `yos` varchar(40) DEFAULT NULL,
  `academic_year` varchar(40) DEFAULT NULL,
  `unit` varchar(40) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL,
  `grade` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `transcripts`
--

INSERT INTO `transcripts` (`id`, `reg_no`, `student`, `yos`, `academic_year`, `unit`, `marks`, `grade`) VALUES
(2, 'TED/118/16', 'rontiago rotiago', '2nd', '2017/2018-1', 'EDF 200', 25, 'E'),
(3, 'TED/118/16', 'rontiago rotiago', '2nd', '2017/2018-1', 'EDU 200', 58, 'C'),
(4, 'TED/118/16', 'rontiago rotiago', '2nd', '2017/2018-1', 'ELT200', 88, 'A'),
(5, 'TED/119/16', 'Caleb Nyairo', '2nd', '2017/2018-1', 'COS200', 76, 'A'),
(6, 'TED/119/16', 'Caleb Nyairo', '2nd', '2017/2018-1', 'EDF 200', 45, 'D'),
(8, 'TED/119/16', 'Caleb Nyairo', '2nd', '2017/2018-1', 'TED 200', 44, 'D');

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `units`
--

INSERT INTO `units` (`id`, `name`) VALUES
(1, 'TED 200'),
(2, 'EDU 200'),
(3, 'EDF 200'),
(4, 'ELT200'),
(5, 'COS200');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_years`
--
ALTER TABLE `academic_years`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exams`
--
ALTER TABLE `exams`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reg_no` (`reg_no`),
  ADD KEY `unit` (`unit`),
  ADD KEY `academic_year` (`academic_year`);

--
-- Indexes for table `membership_grouppermissions`
--
ALTER TABLE `membership_grouppermissions`
  ADD PRIMARY KEY (`permissionID`);

--
-- Indexes for table `membership_groups`
--
ALTER TABLE `membership_groups`
  ADD PRIMARY KEY (`groupID`);

--
-- Indexes for table `membership_userpermissions`
--
ALTER TABLE `membership_userpermissions`
  ADD PRIMARY KEY (`permissionID`);

--
-- Indexes for table `membership_userrecords`
--
ALTER TABLE `membership_userrecords`
  ADD PRIMARY KEY (`recID`),
  ADD UNIQUE KEY `tableName_pkValue` (`tableName`,`pkValue`),
  ADD KEY `pkValue` (`pkValue`),
  ADD KEY `tableName` (`tableName`),
  ADD KEY `memberID` (`memberID`),
  ADD KEY `groupID` (`groupID`);

--
-- Indexes for table `membership_users`
--
ALTER TABLE `membership_users`
  ADD PRIMARY KEY (`memberID`),
  ADD KEY `groupID` (`groupID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reg_no_unique` (`reg_no`);

--
-- Indexes for table `transcripts`
--
ALTER TABLE `transcripts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_years`
--
ALTER TABLE `academic_years`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `exams`
--
ALTER TABLE `exams`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `membership_grouppermissions`
--
ALTER TABLE `membership_grouppermissions`
  MODIFY `permissionID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `membership_groups`
--
ALTER TABLE `membership_groups`
  MODIFY `groupID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `membership_userpermissions`
--
ALTER TABLE `membership_userpermissions`
  MODIFY `permissionID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `membership_userrecords`
--
ALTER TABLE `membership_userrecords`
  MODIFY `recID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `transcripts`
--
ALTER TABLE `transcripts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
