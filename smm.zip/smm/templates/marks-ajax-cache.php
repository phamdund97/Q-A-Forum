<?php
	$rdata = array_map('to_utf8', array_map('nl2br', array_map('html_attr_tags_ok', $rdata)));
	$jdata = array_map('to_utf8', array_map('nl2br', array_map('html_attr_tags_ok', $jdata)));
?>
<script>
	$j(function(){
		var tn = 'marks';

		/* data for selected record, or defaults if none is selected */
		var data = {
			reg_no: <?php echo json_encode(array('id' => $rdata['reg_no'], 'value' => $rdata['reg_no'], 'text' => $jdata['reg_no'])); ?>,
			student: <?php echo json_encode($jdata['student']); ?>,
			unit: <?php echo json_encode(array('id' => $rdata['unit'], 'value' => $rdata['unit'], 'text' => $jdata['unit'])); ?>,
			academic_year: <?php echo json_encode(array('id' => $rdata['academic_year'], 'value' => $rdata['academic_year'], 'text' => $jdata['academic_year'])); ?>
		};

		/* initialize or continue using AppGini.cache for the current table */
		AppGini.cache = AppGini.cache || {};
		AppGini.cache[tn] = AppGini.cache[tn] || AppGini.ajaxCache();
		var cache = AppGini.cache[tn];

		/* saved value for reg_no */
		cache.addCheck(function(u, d){
			if(u != 'ajax_combo.php') return false;
			if(d.t == tn && d.f == 'reg_no' && d.id == data.reg_no.id)
				return { results: [ data.reg_no ], more: false, elapsed: 0.01 };
			return false;
		});

		/* saved value for reg_no autofills */
		cache.addCheck(function(u, d){
			if(u != tn + '_autofill.php') return false;

			for(var rnd in d) if(rnd.match(/^rnd/)) break;

			if(d.mfk == 'reg_no' && d.id == data.reg_no.id){
				$j('#student' + d[rnd]).html(data.student);
				return true;
			}

			return false;
		});

		/* saved value for unit */
		cache.addCheck(function(u, d){
			if(u != 'ajax_combo.php') return false;
			if(d.t == tn && d.f == 'unit' && d.id == data.unit.id)
				return { results: [ data.unit ], more: false, elapsed: 0.01 };
			return false;
		});

		/* saved value for academic_year */
		cache.addCheck(function(u, d){
			if(u != 'ajax_combo.php') return false;
			if(d.t == tn && d.f == 'academic_year' && d.id == data.academic_year.id)
				return { results: [ data.academic_year ], more: false, elapsed: 0.01 };
			return false;
		});

		cache.start();
	});
</script>

