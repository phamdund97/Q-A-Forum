##STUDENT MARKS MANAGEMENT SYSTEM
Developer:Ronald Ronnie
email:ronniengoda@gmail.com
website:http://www.ronaldngoda.is-best.net

#ABOUT
With this system you can easily manage manage marks for university students.The project has a provision where lecturers can be uploading student marks and the marks get added directly to the transcripts with grades.
Students can view marks on a public portal where they can filter their RegNo and Academic year to get results for that particular year.
Students can print the transcripts or save to CSV.
The admin can add lecturers to the system or ban them,can add units,year of study,and exams.

##The transcripts are generated immediately the marks are entered into the system hence no long waiting periods for the transcripts.

Students can create an account to login,lecturers have to be added by admin.